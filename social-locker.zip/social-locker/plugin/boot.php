<?php

if ( !is_admin() ) return;
require( SOCIALLOCKER_DIR . '/plugin/admin/boot.php' );