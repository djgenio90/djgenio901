<?php

// pages
class OPanda_AdminPage extends FactoryPages321_AdminPage  {
 
    /**
     * Factory Dependencies
     * 
     * @since 1.0.0
     * @var string 
     */
    protected $deps = array(
        'factory_core' => FACTORY_325_VERSION
    );
}
