<div class="onp-help-section">
    <h1><?php _e('Creating Social Apps', 'bizpanda'); ?></h1>

    <p><?php _e('Creating own Social Apps is not required in most cases. Click on the links below to know about the cases when you need to create respective apps.', 'bizpanda') ?></p>
    
    <?php $this->showContentTable() ?>
</div>