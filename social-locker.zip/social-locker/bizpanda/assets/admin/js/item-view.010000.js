(function($){
    
    $(function(){

        $(".column-shortcode input").click(function(){
            $(this).select();
        });
        
    });
    
})(jQuery)