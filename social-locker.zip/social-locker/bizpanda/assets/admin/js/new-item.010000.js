if ( !window.opanda ) window.opanda = {};
if ( !window.opanda.newItem ) window.bizpanda.newItem = {};

(function($){
    
    window.opanda.newItem = {
        
        init: function() {
            
            
        }  
    };

    $(function(){
        window.opanda.newItem.init();       
    });
    
})(jQuery)
