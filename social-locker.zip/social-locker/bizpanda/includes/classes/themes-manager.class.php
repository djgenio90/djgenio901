<?php

/* this file is obsolete, marked to remove, redirecting to the right file */
require_once OPANDA_BIZPANDA_DIR . '/includes/themes.php';